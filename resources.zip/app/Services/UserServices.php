<?php
namespace App\Services;


use App\Mail\MyTestEmail;
use App\Mail\TwoFactorCodeMail;
use App\Mail\VerificationEmail;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Http\Requests\LoginRequest;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Helper\ResponseHelper;
use App\Exceptions\InvalidOrderException;
use Illuminate\Http\Json\Response;
use Illuminate\Support\Arr;



class UserServices{
public function UserRegister($or){
    $user= User::create([
        'name'=>$or['name'],
        'email'=>$or['email'],
        'password'=>Hash::make($or['password'])
    ]);
    Mail::to($user->email)->send(new MyTestEmail($user));
   return response()->json([ResponseHelperR('register',$user)] ,201);
  
    }



public function UserLogin($or){
    if (!Auth::attempt(Arr::only($or,['email','password'])))
    return response()->json([ResponseHelperLI()]);
   
   
    $user= User::where('email',$or['email'])->FirstOrFail();
    $token= $user->createToken('auth_token')->plainTextToken; 
    $user->two_factor_code=Str::random(6);
    $user->two_factor_expires_at=now()->addMinutes(10);
    $user->save();

    return response()->json([ResponseHelperL($user,$token)] ,201);

// Mail::to($user->email)->send(new TwoFactorCodeMail($user->two_factor_code));
   
}

public function UserResend($or){

    $user = User::where('email',$or['email'])->first();
    if(!$user){
        throw new InvalidOrderException('User Not Found');
    }
    if($user->code_expires_at && now()->isPast($user->code_expires_at)){
        $user->verification_code=null;
    }
    $verificationCode =Str::random(30);
    $user->verification_code=$verificationCode;
    $user->code_expires_at=now()->addMinutes(5);
    $user->save();
Mail::to($user->email)->send(new VerificationEmail($verificationCode));
    return response()->json([ResponseHelperResend($verificationCode)]);
}

public function UserVerify($or){
    $user=User::where('email',$or['email'])->first();
    if($user->verification_code !==  $or['verification_code'] && now()->isPast($user->code_expires_at)){
      throw new InvalidOrderException('invalid verification');
    }
    $user->verification_code = null;
    $user->code_expires_at =null;
    $user->save();
    return response()->json([ResponseHelperVerfiy()]);
}
public function UserToken($or){
    function responseWithToken($token){
        return response()->json([
            'success'=> true,
            'access_token'=>$token,
            'token_type'=>'Bearer',
           // 'expires_in'=>auth()->factory()->getTTL()*60
        ]);
    }
     
       if(auth()->User() )
        {
            return $this->responseWithToken(auth()->refresh());
        }
        else{
            return response()->json(['success'=>false,'messag'=>'user is not authenticated']);
        }
    
}
}
