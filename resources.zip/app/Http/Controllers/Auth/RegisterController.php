<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use App\Services\UserServices;
use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterRequest;


class RegisterController extends Controller
{
    function register(RegisterRequest $request,UserServices $service)
    { 
       return $service->UserRegister($request->validated()); 
    }
}
