<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\UserServices;
use App\Http\Requests\LoginRequest;

class LoginController extends Controller
{
     function login(LoginRequest $request,UserServices $service)
    {
       return $service->UserLogin($request->validated());
    }
}
