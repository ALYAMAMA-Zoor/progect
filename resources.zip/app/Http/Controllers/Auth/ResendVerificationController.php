<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\ResendVerificationRequest;
use App\Models\User;
use App\Services\UserServices;


class ResendVerificationController extends Controller
{
     function resendVerification(ResendVerificationRequest $request, UserServices $service){
        
        return $service->UserResend($request->validated());
    }
}
