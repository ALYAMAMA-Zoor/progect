<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Http\Requests\VerifyCodeRequest;
use App\Services\UserServices;

class verifyCodeController extends Controller
{
     function verifyCode(VerifyCodeRequest $request, UserServices $service){
        return $service->UserVerify($request->validated());
     }
}
