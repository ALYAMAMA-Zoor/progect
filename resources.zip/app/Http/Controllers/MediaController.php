<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Media;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Exceptions\InvalidOrderException;

class MediaController extends Controller
{
   public function Media(Request $request,$userId){
    $user=User::find($userId);
    if(!$user){
        throw new InvalidOrderException('User not found');
    }
    if($request->hasFile('media')){
        $filePath=$request->file('media')->stor('media');
        $media=new Media(['file_path'=>$filePath]);
        $user->media()->save($media);
        return response()->json([
        'success'=>'media add hiii'
    ],201);
    }
 //throw new InvalidOrderException('no file');
}
}