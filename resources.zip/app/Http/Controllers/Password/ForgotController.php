<?php

namespace App\Http\Controllers\Password;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Password;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\ResetPassworEmail;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Str;
use App\Http\Requests\ForgotRequest;
use Illuminate\Support\Arr;

class ForgotController extends Controller
{
     function sendResetLinkEmail(ForgotRequest $request){
        $request->validated();

    $status =  Password::sendResetLink($request->only('email')) ;

      return $status === Password::RESET_LINK_SENT
         ?response()->json([ 'message'=>__($status)],200)
         :response()->json([ 'message'=>__($status),],400);
 

    }


}
