<?php

namespace App\Http\Controllers\Password;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class TwoFAController extends Controller
{
    public function verify(Request $request){
        $request->validate([
            'two_factor_code'=>'required|string'
        ]);
      // $user=User::where('two_factor_code',$request->two_factor_code)->first();
    $user=auth()->user();
   //  $user=User::where('email',$request->'email')->first();
        if($request->two_factor_code===$user->two_factor_code){
       
            return response()->json(['message'=>'Two Factor successful.']);  

             }  
        return response()->json(['error'=>'invalid'],401); 

    }


}
