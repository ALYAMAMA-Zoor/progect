<?php
namespace App\Http\Controllers\Password;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Password;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Notifications\Notification;
use App\Http\Requests\ResetRequest;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ResetPasswordController extends Controller
{
    public function resetpassword(ResetRequest $request)
    {
        $request->validated();
        $status = Password::reset(  
             $request->only('email', 'password', 'password_confirmation', 'token'),
            function (User $user, string $password) 
            {
                $user->forceFill(['password' => Hash::make($password)])->save();
            }
        )  ;
         
                               
                return $status === Password::RESET_LINK_SENT
                ?response()->json([ 'message'=>__($status)],200)
                :response()->json([ 'message'=>__($status)],400);
   
    }
}

