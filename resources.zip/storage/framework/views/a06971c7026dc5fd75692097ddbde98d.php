<?php
 use App\Http\Controllers\UserController;
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Doc</title>

</head>
<body>
    <h1>Hi <?php echo e($user->name); ?></h1>
    <p>Thank You For Register in our website</p>
    <p>if you wont any help ,please dont think and call us</p>
    
</body>
    </html><?php /**PATH C:\Users\ALYAMAMA\Desktop\laravel\test\resources\views\mail\userEmail.blade.php ENDPATH**/ ?>