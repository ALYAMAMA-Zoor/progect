<h2>Password Reset</h2>
<a herf="{{$url}}">Password reset</a>