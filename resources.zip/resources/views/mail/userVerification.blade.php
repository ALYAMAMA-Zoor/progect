<?php
 use App\Http\Controllers\ResendVerificationController;
 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Doc</title>

</head>
<body>
   <h2> Now Your Verification is:<h2> <h5>{{$verificationCode}}</h5>
   
    
</body>
    </html>