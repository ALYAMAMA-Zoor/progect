<?php
  use App\Http\Controllers\UserController;

 ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Your Two Factor Code</title>

</head>
<body>
    <h1>Your Two Factor Authentication Code</h1>
    <p>Your code is:<strong>{{$code}}</strong></p>
   
    
</body>
    </html> 