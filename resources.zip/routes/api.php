<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\MediaController;
use App\Http\Controllers\Auth\ResendVerificationController;
use App\Http\Controllers\Auth\RefreshTokenController;
use App\Http\Controllers\Auth\verifyCodeController;
use App\Http\Controllers\Password\ForgotController;
use App\Http\Controllers\Password\ResetPasswordController;
use App\Http\Controllers\Password\TwoFAController;


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::post('register',[RegisterController::class,'register']);
Route::post('login',[LoginController::class,'login']);
Route::post('resendVerification',[ResendVerificationController::class,'resendVerification']);
Route::post('verifyCode',[verifyCodeController::class,'verifyCode']);
Route::get('refreshToken',[RefreshTokenController::class,'refreshToken']);
//send email
Route::post('password/email',[ForgotController::class,'sendResetLinkEmail']);
//submit new password
Route::post('password/reset',[ResetPasswordController::class,'resetpassword'])->name('password.reset');


Route::post('two-factor-verify',[TwoFAController::class,'verify']);

Route::post('Media/{userId}',[MediaController::class,'Media']);
